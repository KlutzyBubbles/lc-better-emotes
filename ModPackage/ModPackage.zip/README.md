# VB Can mod
 
Replaces the red soda can with a vb can.


## Incompatible mods

While this mod doesn't break other mods, it can't replace the texture if these mods are used to spawn scrap

- GameMasterDevs-GameMaster
- femboytv-LethalAdjustments
 